
Components

1) Calendar panel
2) Calendar combobox
3) Calendar dialog


Installation

1) BeanBox: File -> LoadJar -> [library path]
2) NetBeans 5: 
  a) "Tools" -> "Library manager" -> "New library..." -> [���� �������� ����������] -> "Add JAR/Folder" -> [library path] -> "OK"
  b) "Tools" -> "Palette manager" -> "Swing/AWT components" -> "Add from library" -> [created library] -> [select need components] -> "Next" -> [select category] -> [Finish] 

Visual editors and presentation are available in

1) English
2) Russian

DateChooser.jar is a executable file, which allows visual customization of all included components (see presentation).


Version 1.1.1
+ setSelectedPeriods(null) selects null if allowed
+ some bugfixes in look & feel support


Version 1.1
+ TableCellRenderer & editor
+ Beans are cloneable
+ javadoc both in english and russian
+ some bugfixes


http://jdatechooser.sourceforge.net/

(c) Androsov Vadim

e-mail: lettervadik@list.ru 

aug-2007